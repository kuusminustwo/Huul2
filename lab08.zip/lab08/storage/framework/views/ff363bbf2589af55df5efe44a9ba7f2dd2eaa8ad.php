

<?php $__env->startSection('title', 'Student List'); ?>

<?php $__env->startSection('content'); ?>
<table border="1">
    <tr>
        <td>#</td>
        <td>Хэнээс</td>
        <td>Хэнд</td>
        <td>Гүйлгээний дүн</td>
        <td>Гүйлгээний утга</td>
    </tr>
    <?php
        $transactions = $transactions->sortByDesc('id');
    ?>
    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($transaction->id); ?></td>
        <td><?php echo e($transaction->transaction_from); ?></a></td>
        <td><?php echo e($transaction->transaction_to); ?></td>
        <td><?php echo e($transaction->transaction_amount); ?></td>
        <td><?php echo e($transaction->transaction_description); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.0.28\htdocs\lab08\resources\views/transactionHistory.blade.php ENDPATH**/ ?>