

<?php $__env->startSection('title', 'Student List'); ?>

<?php $__env->startSection('content'); ?>
    <ul>
        <li><a href='/students/1'>B160910006</a></li>
        <li><a href='/students/2'>B160910023</a></li>
        <li><a href='/students/3'>B160910033</a></li>
    </ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.0.28\htdocs\lab08\resources\views/students.blade.php ENDPATH**/ ?>