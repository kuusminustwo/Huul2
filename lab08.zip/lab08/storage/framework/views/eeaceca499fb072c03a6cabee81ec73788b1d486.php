<!-- resources/views/studentList.blade.php -->



<?php $__env->startSection('title', 'Student List'); ?>

<?php $__env->startSection('content'); ?>
    <ul>
        <li><?php echo e($student->student_id); ?></li>
        <li><?php echo e($student->first_name); ?></li>
        <li><?php echo e($student->surname); ?></li>
        <li><?php echo e($student->age); ?></li>
        <li><?php echo e($student->gender); ?></li>
        <li><?php echo e($student->phone); ?></li>
        <li><?php echo e($student->location); ?></li>
    </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.0.28\htdocs\lab08\resources\views/student.blade.php ENDPATH**/ ?>