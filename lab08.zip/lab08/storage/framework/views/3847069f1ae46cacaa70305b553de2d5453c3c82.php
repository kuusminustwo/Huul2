<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <ul>
            <li><?php echo e($student->student_id); ?></li>
            <li><?php echo e($student->first_name); ?></li>
            <li><?php echo e($student->surname); ?></li>
            <li><?php echo e($student->age); ?></li>
            <li><?php echo e($student->gender); ?></li>
            <li><?php echo e($student->phone); ?></li>
            <li><?php echo e($student->location); ?></li>
        </ul>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html><?php /**PATH C:\xampp8.0.28\htdocs\lab08\resources\views/aboutStudent.blade.php ENDPATH**/ ?>