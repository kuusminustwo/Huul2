<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form action="/search" method="GET">
        <?php echo csrf_field(); ?>
        <input type="text" name="query" placeholder="Search By Student Id">
        <button type="submit">Search</button>
    </form>
</body>
</html><?php /**PATH C:\xampp8.0.28\htdocs\lab08\resources\views/search.blade.php ENDPATH**/ ?>