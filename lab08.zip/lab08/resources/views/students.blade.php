@extends('layouts.master')

@section('title', 'Student List')

@section('content')
    <ul>
        <li><a href='/students/1'>B160910006</a></li>
        <li><a href='/students/2'>B160910023</a></li>
        <li><a href='/students/3'>B160910033</a></li>
    </ul>
@endsection